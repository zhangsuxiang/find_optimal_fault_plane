strike1 = 148; % 第一个断层走向（度）
dip1 = 40;    % 第一个断层倾角（度）
strike2 = 145; % 第二个断层走向（度）
dip2 = 56;     % 第二个断层倾角（度）

angle = fault_plane_angle(strike1, dip1, strike2, dip2);
fprintf('两个断层之间的夹角为 %.2f 度\n', angle);