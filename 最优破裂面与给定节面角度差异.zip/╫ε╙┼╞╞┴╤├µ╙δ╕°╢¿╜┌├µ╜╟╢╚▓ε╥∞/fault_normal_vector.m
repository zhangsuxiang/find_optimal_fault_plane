function n = fault_normal_vector(strike, dip)
% 计算断层法向量（单位向量）
% strike 和 dip 都是弧度制
    n = [ ...
        -sin(dip) * sin(strike);  % X
         sin(dip) * cos(strike);  % Y
        -cos(dip)                 % Z
    ];
end