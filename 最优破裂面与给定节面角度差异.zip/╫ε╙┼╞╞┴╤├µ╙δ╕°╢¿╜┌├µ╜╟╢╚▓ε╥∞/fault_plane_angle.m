function angle_deg = fault_plane_angle(strike1, dip1, strike2, dip2)
% 计算两个断层面的夹角
% 输入：
%   strike1, dip1 - 第一个断层的走向和倾角（单位：度）
%   strike2, dip2 - 第二个断层的走向和倾角（单位：度）
% 输出：
%   angle_deg - 两个断层面法向量之间的夹角（单位：度）

    % 将角度转换为弧度
    strike1 = deg2rad(strike1);
    dip1 = deg2rad(dip1);
    strike2 = deg2rad(strike2);
    dip2 = deg2rad(dip2);

    % 计算断层1的法向量
    n1 = fault_normal_vector(strike1, dip1);

    % 计算断层2的法向量
    n2 = fault_normal_vector(strike2, dip2);

    % 计算夹角（使用点积公式）
    cos_theta = dot(n1, n2) / (norm(n1) * norm(n2));
    cos_theta = min(1, max(-1, cos_theta)); % 修正数值误差
    angle_rad = acos(cos_theta);

    % 转换为度
    angle_deg = rad2deg(angle_rad);
end